<?php

// add geo pro reseller xtream codes api.
$rApiKey = '';

//server domain
$ApiServer = 'tvsat.cc';

//streaming port.
$ApiPort = '8880';

//app dwd link
$appdlink = 'http://geo-iptv.com/ac-player';


?>