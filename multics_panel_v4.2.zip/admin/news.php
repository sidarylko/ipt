<?php
include 'reseller_api.php';

$iptvnews = '<p> The best IPTV Subscription more then 6500+ High Quality channels and 17,000+ movies, series, sports, mangas, documentaries and more in all your devices: <b>Xtream Code Api, Smart TV, Android Smartphone, M3U PC!</b></p>
<p> Click IPTV Line option button Then <b>IPTV Info</b> to get full info of subscription and using formats.</p>
<p> Every IPTV Line will automatically delete from list if not renew after expired for more then 7.days!</p>';

$macnews = '<p> The Best IPTV Subscription more then 5000+ High Quality channels and 21,000+ movies, series, sports, mangas, documentaries and more in all your devices: <b>Smart TV, Mag, Android Smartphone, MAC!</b></p>
<p> Every Mac Address will automatically delete from list if not renew after expired for more then 7.days!</p>';

$activecodenews = '<p> The Best IPTV Subscription more then 6000+ High Quality channels and 25,000+ movies, series, sports, mangas, documentaries and more in all your devices: <b>Android Smart TV, Android Smartphone, Any Anroid Device With Our Specific <a href="'.$appdlink.'">Active Code App</a> Only!</b></p>
<p> Every Activecode will automatically delete from list if not renew after expired for more then 7.days!</p>';

?>