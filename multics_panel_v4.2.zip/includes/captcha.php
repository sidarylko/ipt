<?php
session_start( );
$GsPJnBUZNOmuKYjTGQksuYqSfGDpuXFcYTteN = rand( 100000, 999999 );
$_SESSION[ 'code' ] = $GsPJnBUZNOmuKYjTGQksuYqSfGDpuXFcYTteN;
$SyITsnjiEmchRpPNAtQmybkaVnhbbUqI = imagecreatetruecolor( 60, 20 );
$gzPqEqJBsGgKuqheuNpOSPucroefmasYQWk = imagecolorallocate( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI, 55, 62, 74 );
$sJIJMYHCBBLbYzyCksinizAgPDgWXpogKocls = imagecolorallocate( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI, 255, 255, 255 );
imagefill( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI, 0, 0, $gzPqEqJBsGgKuqheuNpOSPucroefmasYQWk );
imagestring( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI, 5, 0, 0, $GsPJnBUZNOmuKYjTGQksuYqSfGDpuXFcYTteN, $sJIJMYHCBBLbYzyCksinizAgPDgWXpogKocls );
header( "Cache-Control: no-cache, must-revalidate" );
header( 'Content-type: image/png' );
imagepng( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI );
imagedestroy( $SyITsnjiEmchRpPNAtQmybkaVnhbbUqI );
?>
