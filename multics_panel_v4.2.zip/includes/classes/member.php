<?php

class member
{

  private $mcDB;

  public $TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY = array();

  function __construct ( mcDB $eihZqZZpXozVaPkhcTdiuBimglJCwUiNgYdXyM )
  {
    $this->mcDB = $eihZqZZpXozVaPkhcTdiuBimglJCwUiNgYdXyM;
    if ( $this->UzHZzekFDqPEjqnLYjbqsFaBMGLwIOtFHnwL( ) )
    {
      $this->mxtsoWQhbnGScwOfdbnByHeUDeOskCMquGkY( );
    }
  }

  function __destruct ( )
  {
    return true;
  }

  public function UzHZzekFDqPEjqnLYjbqsFaBMGLwIOtFHnwL ( )
  {
    if ( isset( $_SESSION[ 'session_id' ] ) and is_numeric( $_SESSION[ 'session_id' ] ) and isset( $_SESSION[ 'user_id' ] ) )
    {
      $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo = $_SESSION[ 'session_id' ];
      $pXDrlwVXwuxAzlpShefsNcSIaDMBjP = intval( $_SESSION[ 'user_id' ] );
      $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT * FROM `users_sessions` WHERE `id` = '%d'", $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo );
      if ( $this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      {
        $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = $this->mcDB->OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg( );
        if ( ($pXDrlwVXwuxAzlpShefsNcSIaDMBjP != $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'member_id' ]) || (time( ) > $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'expire_date' ]) || ($vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'ip' ] != $_SERVER[ 'REMOTE_ADDR' ]) || ($vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'user_agent' ] != $_SERVER[ 'HTTP_USER_AGENT' ]) || (session_id( ) != $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 'session_id' ]) )
        {
          $this->fNnMHYouaLVCyLJZgYVQUslzxUyVlVBayncfXNc( );
          $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "DELETE FROM `users_sessions` WHERE `id` = '%d'", $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo );
          return false;
        }
        else
        {
          $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "UPDATE `users_sessions` SET `expire_date` = '%d' WHERE `id` = '%d'", strtotime( "+30 mins", time( ) ), $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo );
        }
        return true;
      }
    }
    return false;
  }

  public function qyHtTOkCEvFFROXXBkvXvTZqOsFcnokbjQ ( )
  {
    if ( ! empty( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY ) && $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY[ 'is_admin' ] == 1 )
    {
      return true;
    }
    return false;
  }

  public function aPtRAKrWvpOTMgWfXHBExFXmSvk ( )
  {
    if ( ! empty( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY ) && $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY[ 'is_banned' ] != 1 )
    {
      return true;
    }
    return false;
  }

  public function mxtsoWQhbnGScwOfdbnByHeUDeOskCMquGkY ( )
  {
    $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT t1.*,t2.`is_admin`,t2.`is_banned`,t2.`id` as `group_id`,t2.`group_name`,t2.`percent_discount`,t2.`total_testlines` as `group_testlines` from users t1,member_groups t2 WHERE t1.id = '%d' AND t1.member_group_id = t2.id", $_SESSION[ 'user_id' ] );
    if ( $this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
    {
      $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY = $this->mcDB->OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg( );
    }
    return array();
  }

  public function CMKHygROrmbNPyTkrefFrYYMJWXEZDDZZzNM ( $pXDrlwVXwuxAzlpShefsNcSIaDMBjP )
  {
    $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT * from users WHERE id = '%d'", $pXDrlwVXwuxAzlpShefsNcSIaDMBjP );
    if ( $this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      return $this->mcDB->OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg( );
    return false;
  }

  public function LHLQmEYlCyKYtnmSzMANCpksGuEJJvCkzJmgI ( $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw, $AJdNJaAsADnVbTGUDPSmxBkPkFKNnljIvfVbY, $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, $gabATfkhJtnQcFPzMykJimEDhFvtdvyk, $RKxTAWdldMdOZXchcnlOHddgWKaskxlXXxC, $raWTQRYeCdPLFHibzhhuKoOKyAMWXc = 0, $MMcZDHZevtDkRITxHbzFxeeZdTnpZRzZoxcPg = 3 )
  {
    if ( ! $RKxTAWdldMdOZXchcnlOHddgWKaskxlXXxC || $RKxTAWdldMdOZXchcnlOHddgWKaskxlXXxC < 0 )
      $RKxTAWdldMdOZXchcnlOHddgWKaskxlXXxC = 0;
    $RNInpHwaNKNkFVonLpCknoCXvTBgUvRwPSY = 1;
    if ( isset( $_SESSION[ 'language_guest' ] ) )
    {
      $RNInpHwaNKNkFVonLpCknoCXvTBgUvRwPSY = $_SESSION[ 'language_guest' ][ 'id' ];
    }
    switch ( $RKxTAWdldMdOZXchcnlOHddgWKaskxlXXxC )
    {
      case 1:
        $tWIQQFltPWjmEqDQNuCKxtBgruewJHjBfJXfMCo = mcLib::UQlwNexQoDmmrECjtSvjXkCemiUXftVlJ( );
        $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "INSERT INTO `users` ( `username` , `password` , `email` , `ip` , `date_registered` , `verify_key`, `last_login`, `balance`, `member_group_id`, `verified`, `total_test_lines`, `lang_id` ) VALUES ('%s', '%s', '%s', '%s', '%d', '%s',NULL,'%d','%d',0,0,'%d')", $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw, md5( $AJdNJaAsADnVbTGUDPSmxBkPkFKNnljIvfVbY ), $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, $gabATfkhJtnQcFPzMykJimEDhFvtdvyk, time( ), $tWIQQFltPWjmEqDQNuCKxtBgruewJHjBfJXfMCo, $raWTQRYeCdPLFHibzhhuKoOKyAMWXc, $MMcZDHZevtDkRITxHbzFxeeZdTnpZRzZoxcPg, $RNInpHwaNKNkFVonLpCknoCXvTBgUvRwPSY );
        break;
      case 0:
        $tWIQQFltPWjmEqDQNuCKxtBgruewJHjBfJXfMCo = null;
        $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "INSERT INTO `users` ( `username` , `password` , `email` , `ip` , `date_registered` , `verify_key`, `last_login`, `balance`, `member_group_id`, `verified`, `total_test_lines`, `lang_id` ) VALUES ('%s', '%s', '%s', '%s', '%d', NULL,NULL,'%d','%d',1,0,'%d')", $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw, md5( $AJdNJaAsADnVbTGUDPSmxBkPkFKNnljIvfVbY ), $jivfjPbxvIMXsymDzkiOrwmgbmXAEQQLwYtKyA, $gabATfkhJtnQcFPzMykJimEDhFvtdvyk, time( ), $raWTQRYeCdPLFHibzhhuKoOKyAMWXc, $MMcZDHZevtDkRITxHbzFxeeZdTnpZRzZoxcPg, $RNInpHwaNKNkFVonLpCknoCXvTBgUvRwPSY );
        break;
    }
    if ( $this->mcDB->ULDNqqTHJzNmXeYeEHmcmoXgZdHkcfrjhQlY( ) > 0 )
    {
      return array( $this->mcDB->lZqicXChQNuEPumhIutyOVXkAvvxQGrziptdRBQ( ), $tWIQQFltPWjmEqDQNuCKxtBgruewJHjBfJXfMCo );
    }
    return false;
  }

  public function SCwMRWINiBNcAwZfIlxmMIkCqnpSmc ( $KDFFOFTOIaHKRZUfeQiQDHuCecIboMvFmWQ, $oRjBmIifkcpHFRMENTgIzgNpwZKCQYU )
  {
    $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT id FROM `users` WHERE `$KDFFOFTOIaHKRZUfeQiQDHuCecIboMvFmWQ` = '%s'", $oRjBmIifkcpHFRMENTgIzgNpwZKCQYU );
    return ($this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0) ? $this->mcDB->iycjdDvSoqgLkyJNknsfSqnsRpysAuGjvCAJk( ) : false;
  }

  public function MtatQpoyMWDfTtsnwBFlYIxXCsashwvhaQJrk ( )
  {
    return (isset( $_SESSION[ 'master_server_id' ] )) ? $_SESSION[ 'master_server_id' ] : 0;
  }

  public function enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze ( $pXDrlwVXwuxAzlpShefsNcSIaDMBjP )
  {
    $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT `username` FROM users WHERE id = '%d'", $pXDrlwVXwuxAzlpShefsNcSIaDMBjP );
    if ( $this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
    {
      return $this->mcDB->iycjdDvSoqgLkyJNknsfSqnsRpysAuGjvCAJk( );
    }
    return false;
  }

  public function VmHJtdHLMAZxpCDKcoKhjCFNrnZpsNgdIRk ( $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw, $AJdNJaAsADnVbTGUDPSmxBkPkFKNnljIvfVbY )
  {
    $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT id from users WHERE `username` = '%s' AND `password` = '%s' AND `verified` = 1", $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw, md5( $AJdNJaAsADnVbTGUDPSmxBkPkFKNnljIvfVbY ) );
    $pXDrlwVXwuxAzlpShefsNcSIaDMBjP = $this->mcDB->iycjdDvSoqgLkyJNknsfSqnsRpysAuGjvCAJk( );
    return ($pXDrlwVXwuxAzlpShefsNcSIaDMBjP) ? intval( $pXDrlwVXwuxAzlpShefsNcSIaDMBjP ) : false;
  }

  public function HvQbGcCDTlupQRLmjhKukHGUOVTEnXlluTU ( $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs )
  {
    if ( empty( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY ) )
    {
      $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo = 0;
      $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "SELECT * FROM `users_sessions` WHERE `member_id` = '%d'", $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs );
      if ( $this->mcDB->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      {
        $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ = $this->mcDB->OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg( );
        $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo = $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ[ 'id' ];
        $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "UPDATE `users_sessions` SET `session_id` = '%s',`ip` = '%s',`user_agent` = '%s',`expire_date` = '%d' WHERE `member_id` = '%d'", session_id( ), $_SERVER[ 'REMOTE_ADDR' ], $_SERVER[ 'HTTP_USER_AGENT' ], strtotime( "+20 mins" ), $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs );
      }
      else
      {
        $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "INSERT INTO `users_sessions` (`member_id`,`session_id`,`user_agent`,`ip`,`expire_date`) VALUES('%d','%s','%s','%s','%d')", $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs, session_id( ), $_SERVER[ 'HTTP_USER_AGENT' ], $_SERVER[ 'REMOTE_ADDR' ], strtotime( "+20 mins" ) );
        $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo = $this->mcDB->lZqicXChQNuEPumhIutyOVXkAvvxQGrziptdRBQ( );
      }
      $_SESSION[ 'session_id' ] = $XkqmoAmZrzkVQCuSCEWcZSfplzNpLUo;
      $_SESSION[ 'user_id' ] = $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs;
      $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "UPDATE users set `last_login` = '%d',`ip` = '%s' WHERE id = '%d'", time( ), $_SERVER[ 'REMOTE_ADDR' ], $vhzmlWdPwuEOqRGBmRpmsfOHwDCCGOIs );
      $this->mxtsoWQhbnGScwOfdbnByHeUDeOskCMquGkY( );
      if ( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY[ 'is_admin' ] == 1 )
      {
        if ( is_array( DgfgKeLTBlEfWDyjkTOzsQlcHqEnvKKJexY( ) ) )
        {
          $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "UPDATE `multics_licence` SET `update_available` = 1 WHERE `id` = 1" );
        }
        else
        {
          $this->mcDB->okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg( "UPDATE `multics_licence` SET `update_available` = 0 WHERE `id` = 1" );
        }
      }
    }
  }

  public function MGCyxllJMFrDgtAnxzJqYqUCtHbDwlQcjAavGc ( )
  {
    if ( ! empty( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY ) && $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY[ 'is_banned' ] != 1 )
    {
      if ( $this->TufInpZBGNPOOTyQYSTpJwrcPkpYlDxlUkhvFY[ 'is_admin' ] != 1 )
      {
        header( 'Location: ./userpanel/index.php' );
        exit( 0 );
      }
      else
      {
        header( 'Location: ./admin/index.php' );
        exit( 0 );
      }
    }
  }

  public function fNnMHYouaLVCyLJZgYVQUslzxUyVlVBayncfXNc ( )
  {
    @session_unset( );
    @session_destroy( );
  }
}
?>
