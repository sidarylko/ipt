<?php

class mcdb
{

  var $EwyUmraOWUEjWxRuCMIYOHOFJEmhliEoniSHE = 0;

  protected $CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws;

  var $fgjcPuIlYkGGfOUxmDEHItMGlDXWnUmskI;

  protected $FYvlAHHdLXUGtkRrsOAalaGTtgisccZxzU;

  protected $MeNnorFhvxXbSoBwbDXxNpFeBHWUWmdEEWt;

  protected $GcJEwrCMpdjACnrWOHsgQnWiCwPiqrXqk;

  protected $CScjoGyVZSPaSYnCEHwOmuxjelKuBQgQPNCsw;

  protected $scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM;

  function __construct ( $FYvlAHHdLXUGtkRrsOAalaGTtgisccZxzU, $MeNnorFhvxXbSoBwbDXxNpFeBHWUWmdEEWt, $GcJEwrCMpdjACnrWOHsgQnWiCwPiqrXqk, $CScjoGyVZSPaSYnCEHwOmuxjelKuBQgQPNCsw )
  {
    $this->FYvlAHHdLXUGtkRrsOAalaGTtgisccZxzU = $FYvlAHHdLXUGtkRrsOAalaGTtgisccZxzU;
    $this->MeNnorFhvxXbSoBwbDXxNpFeBHWUWmdEEWt = $MeNnorFhvxXbSoBwbDXxNpFeBHWUWmdEEWt;
    $this->GcJEwrCMpdjACnrWOHsgQnWiCwPiqrXqk = $GcJEwrCMpdjACnrWOHsgQnWiCwPiqrXqk;
    $this->CScjoGyVZSPaSYnCEHwOmuxjelKuBQgQPNCsw = $CScjoGyVZSPaSYnCEHwOmuxjelKuBQgQPNCsw;
    $this->FkgluNHEmpslCRhVcIPUGSxRTWpRIPRuGrP( );
  }

  function __destruct ( )
  {
    mysqli_close( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM );
    return true;
  }

  function FkgluNHEmpslCRhVcIPUGSxRTWpRIPRuGrP ( )
  {
    $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM = mysqli_connect( $this->CScjoGyVZSPaSYnCEHwOmuxjelKuBQgQPNCsw, $this->FYvlAHHdLXUGtkRrsOAalaGTtgisccZxzU, $this->MeNnorFhvxXbSoBwbDXxNpFeBHWUWmdEEWt, $this->GcJEwrCMpdjACnrWOHsgQnWiCwPiqrXqk );
    if ( mysqli_connect_errno( ) )
    {
      die( "Can Not Contect to database. Please check your config details." );
    }
    return true;
  }

  function okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg ( $okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg )
  {
    if ( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM )
    {
      $uwKPQcQIbZqWPJINqWjycBcsXDFsEZdMoM = func_num_args( );
      $vejaLSNVdOixjNJOLDRSppIoUwOYoxPtokrA = func_get_args( );
      $ERGELweuWItIbbYBTydvNpnSgMuSXyAuqI = array();
      for ( $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII = 1; $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII < $uwKPQcQIbZqWPJINqWjycBcsXDFsEZdMoM; $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII++ )
      {
        $ERGELweuWItIbbYBTydvNpnSgMuSXyAuqI[ ] = mysqli_real_escape_string( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM, $vejaLSNVdOixjNJOLDRSppIoUwOYoxPtokrA[ $PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII ] );
      }
      $okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg = vsprintf( $okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg, $ERGELweuWItIbbYBTydvNpnSgMuSXyAuqI );
      $this->fgjcPuIlYkGGfOUxmDEHItMGlDXWnUmskI = $okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg;
      $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws = mysqli_query( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM, $okIIAkTGwbUuDqjVZeDZLjPlJuLxPCAbQRg );
      $this->EwyUmraOWUEjWxRuCMIYOHOFJEmhliEoniSHE++;
    }
  }

  function uRkfhIjOyHziEyCiTLMEUfuMfkXqDIgnaoo ( )
  {
    if ( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM && $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws )
    {
      $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl = array();
      if ( $this->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      {
        while ( $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = mysqli_fetch_array( $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws, MYSQLI_ASSOC ) )
        {
          $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl[ ] = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs;
        }
      }
      return $DqxWVhFTLNAKTbhfsRUoDwEXckDTaziPWl;
    }
    return false;
  }

  public function OywkjiJsPsfQksGnfpNDuDtblCYOpOluCAWg ( )
  {
    if ( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM && $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws )
    {
      $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = array();
      if ( $this->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      {
        $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = mysqli_fetch_array( $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws, MYSQLI_ASSOC );
      }
      return $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs;
    }
    return false;
  }

  public function iycjdDvSoqgLkyJNknsfSqnsRpysAuGjvCAJk ( )
  {
    if ( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM && $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws )
    {
      $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = false;
      if ( $this->mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU( ) > 0 )
      {
        $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = mysqli_fetch_array( $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws, MYSQLI_NUM );
        $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs = $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs[ 0 ];
      }
      return $vhFTvdzxPpZQiQAJJtlRbuPQHrcAITvcNdrSEJs;
    }
    return false;
  }

  public function ULDNqqTHJzNmXeYeEHmcmoXgZdHkcfrjhQlY ( )
  {
    return mysqli_affected_rows( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM );
  }

  public function KuLojXalqFapMKiJwMGlLOwCWRiHOeSJTg ( )
  {
    return mysqli_num_fields( $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws );
  }

  public function lZqicXChQNuEPumhIutyOVXkAvvxQGrziptdRBQ ( )
  {
    return mysqli_insert_id( $this->scrxBkWdHgCSLBsJQxEynAXUhdSMmIjpilM );
  }

  public function mSgFNAoJuzlttvDkYoMsAbRCiKUPbFVEFzU ( )
  {
    return mysqli_num_rows( $this->CMhvQGjGDCfCqMKXlWxUUPihwPzVEYtVGEws );
  }
}
?>
